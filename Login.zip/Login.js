//import { useNavigate } from "react-router-dom";

export default function Login() {
//   const navigate = useNavigate();
    function loginHandler(event) {
       event.preventDefault();
       const inpName = document.getElementById("User").value
       const inpPw = document.getElementById("Pass").value
       if(inpName === 'Adrian' && inpPw === '12345'){
         alert('Login Berhasil')
       } else {
         alert('Login Gagal')
       }
       
       //  alert(inpName)
      //  alert(inpPw)
      //  const checkLogin = true;
      //  if(checkLogin){
      //     navigate('/dashboard');
      //  } 
    }
    

  return (
     <form onSubmit={loginHandler}>
        <input type="text" name="Username" id="User"/><br></br>
        <input type="password" name="Password" id="Pass"/><br></br>
        <button>Login</button>
     </form>
  );
  }
  

